#include <iostream>
#include <string>
#include "MainMachine.h"
using namespace std;

int main() {
    MainMachine machine;
    int choice = 0;
    string filename;

    while (true) {
        cout << "\n=========================================\n";
        cout << "      VOLE MACHINE SIMULATOR (CS213)     \n";
        cout << "=========================================\n";
        cout << "1. Load Program from File\n";
        cout << "2. Run Program (Continuous)\n";
        cout << "3. Run Program (Step-by-step)\n";
        cout << "4. Display Machine Status (Memory & Regs)\n";
        cout << "5. Exit\n";
        cout << "-----------------------------------------\n";
        cout << "Enter your choice (1-5): ";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter program filename (e.g., program1.txt): ";
            cin >> filename;
            machine.loadProgramFromFile(filename);
        }
        else if (choice == 2) {
            cout << "\nExecuting program continuously...\n";
            machine.runContinuous();
            machine.displayStatus();
        }
        else if (choice == 3) {
            cout << "\nExecuting step-by-step...\n";
            machine.runStepByStep();
            machine.displayStatus();
        }
        else if (choice == 4) {
            machine.displayStatus();
        }
        else if (choice == 5) {
            cout << "Exiting Vole Simulator. Goodbye!\n";
            break;
        }
        else {
            cout << "Invalid choice! Please select 1-5.\n";
        }
    }

    return 0;
}
