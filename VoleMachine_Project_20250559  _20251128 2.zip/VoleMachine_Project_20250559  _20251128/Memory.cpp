#include "Memory.h"
#include <iostream>
#include <iomanip>

Memory::Memory(int size) {
    cells.resize(size, "00");
}

void Memory::setCell(int address, std::string value) {
    if (address >= 0 && address < cells.size()) {
        cells[address] = value;
    }
}

std::string Memory::getCell(int address) {
    if (address >= 0 && address < cells.size()) {
        return cells[address];
    }
    return "00";
}

void Memory::display() {
    std::cout << "\n--- Memory State ---\n";

    for (int i = 0; i < cells.size(); i++) {
        std::cout << "[" << std::hex << std::uppercase << i
                  << "]: " << cells[i] << "  ";

        if ((i + 1) % 16 == 0)
            std::cout << '\n';
    }

    std::cout << std::dec;
}

