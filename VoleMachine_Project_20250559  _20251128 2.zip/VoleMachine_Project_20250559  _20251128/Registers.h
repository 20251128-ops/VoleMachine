#ifndef REGISTERS_H
#define REGISTERS_H

#include <vector>
#include <string>

class Registers {
private:
    std::vector<std::string> regList;

public:
    Registers(int size = 16);
    void setRegister(int index, std::string value);
    std::string getRegister(int index);
    void display();
};

#endif

