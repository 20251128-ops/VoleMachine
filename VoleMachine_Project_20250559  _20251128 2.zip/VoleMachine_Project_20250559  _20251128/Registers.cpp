#include "Registers.h"
#include <iostream>
#include <iomanip>

Registers::Registers(int size) {
    regList.resize(size, "00");
}

void Registers::setRegister(int index, std::string value) {
    if (index >= 0 && index < regList.size()) {
        regList[index] = value;
    }
}

std::string Registers::getRegister(int index) {
    if (index >= 0 && index < regList.size()) {
        return regList[index];
    }
    return "00";
}

void Registers::display() {
    std::cout << "\n--- Registers State ---\n";
    for (int i = 0; i < regList.size(); i++) {
        std::cout << "R" << std::hex << std::uppercase << i
                  << ": " << regList[i] << "  ";
        if ((i + 1) % 8 == 0) {
            std::cout << '\n';
        }
    }
    std::cout << std::dec;
}

