#ifndef MEMORY_H
#define MEMORY_H

#include <vector>
#include <string>

class Memory {
private:
    std::vector<std::string> cells;

public:
    Memory(int size = 256);
    void setCell(int address, std::string value);
    std::string getCell(int address);
    void display();
};

#endif

